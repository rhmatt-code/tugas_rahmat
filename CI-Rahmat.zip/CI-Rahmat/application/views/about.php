<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/uikit@3.11.1/dist/css/uikit.min.css" />
    <script src="https://cdn.jsdelivr.net/npm/uikit@3.11.1/dist/js/uikit.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/uikit@3.11.1/dist/js/uikit-icons.min.js"></script>
</head>
<body>
<nav class="uk-background-secondary " style="background-color :black;" uk-navbar>
    <div class="uk-navbar-left">
        <ul class="uk-navbar-nav">
                <li><a href="login">Login</a></li>                      
        </ul>
    </div>
        <div class="uk-navbar-center">
            <ul class="uk-navbar-nav">
                <li><a href="home">Home</a></li>
                <li><a href="about">About</a></li>                          
            </ul>
        </div>
    <div class="uk-navbar-right">
        <ul class="uk-navbar-nav">
                <li><a href="register">Register</a></li>                      
        </ul>
    </div>
</nav>
<h2 class="uk-text-center"> About This Web</h2>
<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quia vero amet voluptate, dolorum omnis incidunt enim praesentium eaque. Nesciunt numquam soluta iusto animi, libero sapiente quis laudantium! Impedit, obcaecati recusandae!locale_filter_matches Lorem ipsum dolor sit amet consectetur adipisicing elit. Sunt libero a laboriosam consequatur quam iusto nobis facilis perferendis. Non nemo consequuntur, similique reprehenderit sed provident inventore nobis numquam esse soluta. Lorem ipsum dolor sit amet consectetur adipisicing elit. Et odio corporis maiores quasi, repellat fugit doloremque atque quis, aperiam odit culpa deserunt iure hic dicta sed amet eos nobis soluta. Lorem ipsum dolor sit amet consectetur adipisicing elit. Quaerat sit impedit saepe assumenda. Distinctio dignissimos alias fugiat accusantium quo, debitis iste quasi, tempore officia, temporibus magni! Repudiandae atque rem ex.</p>
</body>
</html>