<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/uikit@3.15.21/dist/css/uikit.min.css" />
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body>
     <div class="uk-container">
        <div class="uk-card-header uk-position-center">
            <div class="uk-grid-small uk-flex-middle" uk-grid>
                <div class="uk-width-expand">
                    <h3 class="uk-card-title uk-margin-remove-bottom uk-text-center">Login</h3>
                </div>
                <div class="uk-card-body-small">
                    <form action="home">
                        <div class="uk-margin">
                            <span>Name <input class="uk-input" type="text" name="name"></span>
                            <span>Password <input class="uk-input" type="password" name="password"></span>
                        </div>
                        <div class="uk-text-center">
                            <button class="uk-button uk-button-secondary">Login</button>
                        </div>                    
                    </form>
                </div>
            </div>
        </div>
     </div>
</body>
</html>