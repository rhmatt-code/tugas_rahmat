<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/uikit@3.11.1/dist/css/uikit.min.css" />
    <script src="https://cdn.jsdelivr.net/npm/uikit@3.11.1/dist/js/uikit.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/uikit@3.11.1/dist/js/uikit-icons.min.js"></script>
</head>
<body>
<nav class="uk-background-secondary " style="background-color :black;" uk-navbar>
    <div class="uk-navbar-left">
        <ul class="uk-navbar-nav">
                <li><a href="login">Login</a></li>                      
        </ul>
    </div>
        <div class="uk-navbar-center">
            <ul class="uk-navbar-nav">
                <li><a href="home">Home</a></li>
                <li><a href="about">About</a></li>                          
            </ul>
        </div>
    <div class="uk-navbar-right">
        <ul class="uk-navbar-nav">
                <li><a href="register">Register</a></li>                      
        </ul>
    </div>
</nav>
<div class="uk-height-medium uk-flex uk-flex-center uk-flex-middle uk-background-cover"
     data-src="https://www.smam3sda.sch.id/upload/picture/35319990aaaa.jpg"
     data-srcset="https://www.smam3sda.sch.id/upload/picture/35319990aaaa.jpg 650w,
     https://www.smam3sda.sch.id/upload/picture/35319990aaaa.jpg 1300w"
     sizes="(min-width: 650px) 650px, 100vw" uk-img>
    <h1 class="uk-text-muted uk-text-bolder">SMK MUHAMMADIYAH</h1>
</div>
<p class="uk-container">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolorum obcaecati distinctio facilis illo? Et minus cupiditate in commodi necessitatibus, veritatis voluptatum, architecto ullam amet suscipit beatae laboriosam soluta assumenda temporibus. Lorem ipsum dolor sit, amet consectetur adipisicing elit. Corporis, aut distinctio cum eaque aperiam corrupti, quis quidem, modi aliquam velit dolor. Minus quam veritatis veniam dolores nobis nulla assumenda. Cupiditate! Lorem ipsum dolor sit amet consectetur adipisicing elit. Hic eius omnis commodi magni error in odio officia quia sunt, similique molestias vel doloribus quaerat amet aliquid, laudantium perferendis, doloremque facere.
    Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quisquam temporibus rerum quis tempora tempore, quam cumque pariatur sed eaque eum veniam, nostrum consequuntur iure voluptates illum atque, iste officiis. Quas!locale_filter_matches Lorem ipsum dolor sit amet consectetur, adipisicing elit. Expedita, dicta vitae perspiciatis quisquam tempora eveniet nobis suscipit rem? Deserunt reprehenderit odio distinctio minima fugiat aut consequuntur qui, corrupti ea commodi!
</p>
</body>
</html>